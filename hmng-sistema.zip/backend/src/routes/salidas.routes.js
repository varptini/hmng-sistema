module.exports = require('./_extra.routes').salidasRouter;
