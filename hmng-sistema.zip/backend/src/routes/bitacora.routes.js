module.exports = require('./_combined.routes').bitacoraRouter;
