const express = require('express');
const { authenticate, authorize } = require('../middleware/auth');
const { query } = require('../db/pool');

// ─── ROLES ─────────────────────────────────────────────────
const rolesRouter = express.Router();
rolesRouter.use(authenticate);
rolesRouter.get('/', async (req, res, next) => {
  try { res.json((await query('SELECT * FROM roles ORDER BY id')).rows); } catch(e) { next(e); }
});
module.exports.rolesRouter = rolesRouter;

// ─── SERVICIOS ──────────────────────────────────────────────
const serviciosRouter = express.Router();
serviciosRouter.use(authenticate);
serviciosRouter.get('/', async (req, res, next) => {
  try { res.json((await query('SELECT * FROM servicios WHERE activo=true ORDER BY nombre')).rows); } catch(e) { next(e); }
});
serviciosRouter.post('/', authorize('Administrador'), async (req, res, next) => {
  try {
    const { nombre, descripcion } = req.body;
    const r = await query('INSERT INTO servicios(nombre,descripcion) VALUES($1,$2) RETURNING *', [nombre, descripcion]);
    res.status(201).json(r.rows[0]);
  } catch(e) { next(e); }
});
serviciosRouter.put('/:id', authorize('Administrador'), async (req, res, next) => {
  try {
    const { nombre, descripcion, activo } = req.body;
    const r = await query('UPDATE servicios SET nombre=COALESCE($1,nombre),descripcion=COALESCE($2,descripcion),activo=COALESCE($3,activo) WHERE id=$4 RETURNING *',
      [nombre, descripcion, activo, req.params.id]);
    res.json(r.rows[0]);
  } catch(e) { next(e); }
});
module.exports.serviciosRouter = serviciosRouter;

// ─── EMPLEADOS ──────────────────────────────────────────────
const empleadosRouter = express.Router();
empleadosRouter.use(authenticate, authorize('Administrador'));
empleadosRouter.get('/', async (req, res, next) => {
  try { res.json((await query('SELECT * FROM empleados WHERE activo=true ORDER BY nombre')).rows); } catch(e) { next(e); }
});
empleadosRouter.post('/', async (req, res, next) => {
  try {
    const { nombre, direccion, telefono, correo, celular, fecha_nacimiento } = req.body;
    const r = await query('INSERT INTO empleados(nombre,direccion,telefono,correo,celular,fecha_nacimiento) VALUES($1,$2,$3,$4,$5,$6) RETURNING *',
      [nombre, direccion, telefono, correo, celular, fecha_nacimiento]);
    res.status(201).json(r.rows[0]);
  } catch(e) { next(e); }
});
empleadosRouter.put('/:id', async (req, res, next) => {
  try {
    const { nombre, direccion, telefono, correo, celular } = req.body;
    const r = await query('UPDATE empleados SET nombre=COALESCE($1,nombre),direccion=COALESCE($2,direccion),telefono=COALESCE($3,telefono),correo=COALESCE($4,correo),celular=COALESCE($5,celular) WHERE id=$6 RETURNING *',
      [nombre, direccion, telefono, correo, celular, req.params.id]);
    res.json(r.rows[0]);
  } catch(e) { next(e); }
});
empleadosRouter.delete('/:id', async (req, res, next) => {
  try {
    await query('UPDATE empleados SET activo=false WHERE id=$1', [req.params.id]);
    res.json({ message: 'Empleado desactivado' });
  } catch(e) { next(e); }
});
module.exports.empleadosRouter = empleadosRouter;

// ─── BITÁCORA ────────────────────────────────────────────────
const bitacoraRouter = express.Router();
bitacoraRouter.use(authenticate);
bitacoraRouter.get('/', async (req, res, next) => {
  try {
    const { insumo_id, tipo, desde, hasta, page=1, limit=30 } = req.query;
    const params = []; const conds = [];
    if (insumo_id) { params.push(insumo_id); conds.push(`b.insumo_id=$${params.length}`); }
    if (tipo) { params.push(tipo); conds.push(`b.tipo=$${params.length}`); }
    if (desde) { params.push(desde); conds.push(`b.fecha>=$${params.length}`); }
    if (hasta) { params.push(hasta); conds.push(`b.fecha<=$${params.length}`); }
    const where = conds.length ? 'WHERE '+conds.join(' AND ') : '';
    params.push(limit, (page-1)*limit);
    const r = await query(`SELECT b.*,i.nombre as insumo_nombre,i.unidad_medida,emp.nombre as usuario_nombre
      FROM bitacora b JOIN insumos i ON b.insumo_id=i.id JOIN usuarios u ON b.usuario_id=u.id JOIN empleados emp ON u.empleado_id=emp.id
      ${where} ORDER BY b.fecha DESC LIMIT $${params.length-1} OFFSET $${params.length}`, params);
    res.json({ data: r.rows });
  } catch(e) { next(e); }
});
module.exports.bitacoraRouter = bitacoraRouter;

// ─── NOTIFICACIONES ──────────────────────────────────────────
const notificacionesRouter = express.Router();
notificacionesRouter.use(authenticate);
notificacionesRouter.get('/', async (req, res, next) => {
  try {
    const r = await query('SELECT * FROM notificaciones WHERE usuario_id=$1 ORDER BY created_at DESC LIMIT 30', [req.user.id]);
    const noLeidas = await query('SELECT COUNT(*) FROM notificaciones WHERE usuario_id=$1 AND leida=false', [req.user.id]);
    res.json({ data: r.rows, no_leidas: parseInt(noLeidas.rows[0].count) });
  } catch(e) { next(e); }
});
notificacionesRouter.put('/marcar-leidas', async (req, res, next) => {
  try {
    await query('UPDATE notificaciones SET leida=true WHERE usuario_id=$1', [req.user.id]);
    res.json({ message: 'Notificaciones marcadas como leídas' });
  } catch(e) { next(e); }
});
module.exports.notificacionesRouter = notificacionesRouter;

// ─── DASHBOARD ───────────────────────────────────────────────
const dashboardRouter = express.Router();
dashboardRouter.use(authenticate);
const { getStats } = require('../controllers/dashboard.controller');
dashboardRouter.get('/', getStats);
module.exports.dashboardRouter = dashboardRouter;
