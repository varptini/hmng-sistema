module.exports = require('./_combined.routes').empleadosRouter;
