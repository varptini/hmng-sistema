module.exports = require('./_combined.routes').dashboardRouter;
