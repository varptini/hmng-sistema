const express = require('express');
const { authenticate, authorize } = require('../middleware/auth');
const { query, getClient } = require('../db/pool');
const { registrarAuditoria } = require('../utils/auditoria');

// ─── PEDIDOS ALMACÉN GENERAL ────────────────────────────────
const pedidosAlmacenRouter = express.Router();
pedidosAlmacenRouter.use(authenticate);

pedidosAlmacenRouter.get('/', async (req, res, next) => {
  try {
    const r = await query(
      `SELECT p.*, ag.nombre as almacen_nombre, emp.nombre as usuario_nombre
       FROM pedidos_almacen_general p
       LEFT JOIN almacen_general ag ON p.almacen_general_id = ag.id
       JOIN usuarios u ON p.usuario_id = u.id
       JOIN empleados emp ON u.empleado_id = emp.id
       ORDER BY p.fecha_pedido DESC`
    );
    res.json({ data: r.rows });
  } catch(e) { next(e); }
});

pedidosAlmacenRouter.get('/:id', async (req, res, next) => {
  try {
    const pedido = await query(`SELECT p.*, ag.nombre as almacen_nombre FROM pedidos_almacen_general p LEFT JOIN almacen_general ag ON p.almacen_general_id=ag.id WHERE p.id=$1`, [req.params.id]);
    if (!pedido.rows.length) return res.status(404).json({ error: 'No encontrado' });
    const detalles = await query(`SELECT d.*, i.nombre as insumo_nombre, i.unidad_medida FROM detalle_pedidos_almacen d JOIN insumos i ON d.insumo_id=i.id WHERE d.pedido_almacen_id=$1`, [req.params.id]);
    res.json({ ...pedido.rows[0], detalles: detalles.rows });
  } catch(e) { next(e); }
});

pedidosAlmacenRouter.post('/', authorize('Administrador','Abastecedor'), async (req, res, next) => {
  const client = await getClient();
  try {
    await client.query('BEGIN');
    const { almacen_general_id, observaciones, detalles } = req.body;
    if (!detalles?.length) return res.status(400).json({ error: 'Se requiere al menos un insumo' });
    const pedido = await client.query(
      `INSERT INTO pedidos_almacen_general (usuario_id, almacen_general_id, observaciones) VALUES ($1,$2,$3) RETURNING *`,
      [req.user.id, almacen_general_id, observaciones]
    );
    for (const item of detalles) {
      await client.query(
        `INSERT INTO detalle_pedidos_almacen (pedido_almacen_id, insumo_id, cantidad_solicitada) VALUES ($1,$2,$3)`,
        [pedido.rows[0].id, item.insumo_id, item.cantidad]
      );
    }
    await client.query('COMMIT');
    await registrarAuditoria(req.user.id, 'CREAR_PEDIDO_ALMACEN', 'pedidos_almacen_general', `Pedido #${pedido.rows[0].id}`);
    res.status(201).json({ id: pedido.rows[0].id, message: 'Pedido creado' });
  } catch(e) { await client.query('ROLLBACK'); next(e); } finally { client.release(); }
});

pedidosAlmacenRouter.put('/:id/estado', authorize('Administrador','Abastecedor'), async (req, res, next) => {
  try {
    const { estado } = req.body;
    const extra = estado === 'recibido' ? ', fecha_recepcion = NOW()' : '';
    await query(`UPDATE pedidos_almacen_general SET estado=$1${extra} WHERE id=$2`, [estado, req.params.id]);
    res.json({ message: 'Estado actualizado' });
  } catch(e) { next(e); }
});

module.exports.pedidosAlmacenRouter = pedidosAlmacenRouter;

// ─── SALIDAS ─────────────────────────────────────────────────
const salidasRouter = express.Router();
salidasRouter.use(authenticate);
salidasRouter.get('/', async (req, res, next) => {
  try {
    const r = await query(
      `SELECT s.*, sv.nombre as servicio_nombre, emp.nombre as usuario_nombre
       FROM salidas s JOIN servicios sv ON s.servicio_id=sv.id
       JOIN usuarios u ON s.usuario_id=u.id JOIN empleados emp ON u.empleado_id=emp.id
       ORDER BY s.fecha_registro DESC LIMIT 50`
    );
    res.json({ data: r.rows });
  } catch(e) { next(e); }
});
module.exports.salidasRouter = salidasRouter;

// ─── REPORTES ────────────────────────────────────────────────
const reportesRouter = express.Router();
reportesRouter.use(authenticate);
reportesRouter.get('/inventario', async (req, res, next) => {
  try {
    const r = await query(
      `SELECT id, nombre, descripcion, unidad_medida, existencia, cantidad_minima, lote, fecha_caducidad,
        CASE WHEN fecha_caducidad < NOW() THEN 'caducado'
             WHEN fecha_caducidad <= NOW() + INTERVAL '30 days' THEN 'por_caducar'
             ELSE 'vigente' END as estado_caducidad,
        CASE WHEN existencia = 0 THEN 'agotado'
             WHEN existencia <= cantidad_minima THEN 'stock_bajo'
             ELSE 'normal' END as estado_stock
       FROM insumos WHERE activo=true ORDER BY nombre`
    );
    res.json({ data: r.rows, fecha_reporte: new Date() });
  } catch(e) { next(e); }
});

reportesRouter.get('/movimientos', async (req, res, next) => {
  try {
    const { desde, hasta } = req.query;
    const params = desde && hasta ? [desde, hasta] : [];
    const where = params.length ? `WHERE b.fecha BETWEEN $1 AND $2` : '';
    const r = await query(
      `SELECT b.*, i.nombre as insumo_nombre, i.unidad_medida, emp.nombre as usuario_nombre
       FROM bitacora b JOIN insumos i ON b.insumo_id=i.id
       JOIN usuarios u ON b.usuario_id=u.id JOIN empleados emp ON u.empleado_id=emp.id
       ${where} ORDER BY b.fecha DESC`, params
    );
    res.json({ data: r.rows, fecha_reporte: new Date() });
  } catch(e) { next(e); }
});
module.exports.reportesRouter = reportesRouter;
